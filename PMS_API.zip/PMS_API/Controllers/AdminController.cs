﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PMS_API.Models;
using PMS_MVC.Models;

namespace PMS_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        PMSDbContext db = null;
        public AdminController(PMSDbContext context)
        {
            this.db = context;
        }
        [HttpPost]
        [Route("AdminLogin")]
        public IActionResult AdminLogin([FromBody] Admin aLog)
        {
            if (aLog.UserName == null || aLog.Password == null)
            {
                return BadRequest();
            }
            if (aLog.UserName == "admin@wipro.com" && aLog.Password == "admin123")
            {
                return Ok("Admin Login done !!");
            }
            return BadRequest("login fail..!");
        }
        [HttpGet]
        public IActionResult GetList()
        {
            return Ok(db.Users.ToList());
        }
        [HttpGet]
        [Route("{id}")]
        public IActionResult GetById(int id)
        {
            try
            {
                var customer = db.Users.Find(id);

                return Ok(customer);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpPut]
        [Route("{id}")]
        public IActionResult UpdateCustomerDetails([FromBody] UserModel user, int id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            var userToBeUpdated = db.Users.Find(id);
            if (userToBeUpdated.LoginId == id)
            {
                userToBeUpdated.EmailId = user.EmailId;
                userToBeUpdated.DOB = user.DOB;
                userToBeUpdated.FirstName = user.FirstName;
                userToBeUpdated.LastName = user.LastName;
                userToBeUpdated.Gender = user.Gender;
                userToBeUpdated.Address = user.Address;
                userToBeUpdated.State = user.State;
                userToBeUpdated.City = user.City;
                userToBeUpdated.Country = user.Country;
                userToBeUpdated.Pincode = user.Pincode;
                userToBeUpdated.MobileNumber = user.MobileNumber;
                db.Users.Update(userToBeUpdated);
                db.SaveChanges();
                return Ok("Details Updated successfully !!");
            }
            return BadRequest("Invalid Details...");
        }
        [HttpDelete]
        [Route("{id}")]
        public IActionResult DeleteUser(int id)
        {
            if (id == null)
            {
                return BadRequest();
            }
            var userToBeDeleted = db.Users.Find(id);
            if (userToBeDeleted != null)
            {
                db.Users.Remove(userToBeDeleted);
                db.SaveChanges();
                return Ok("User Deleted successfully !!");
            }
            return BadRequest("User with provided details doesn't exist!!");
        }
    }
}

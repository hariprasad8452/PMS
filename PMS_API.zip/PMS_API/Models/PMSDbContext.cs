﻿using Microsoft.EntityFrameworkCore;

namespace PMS_API.Models
{
    public class PMSDbContext : DbContext
    {
        public PMSDbContext(DbContextOptions<PMSDbContext> options) : base(options)
        {
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //modelBuilder.HasSequence("BranchSequence")
            //   .StartsAt(5000).IncrementsBy(5);
            //modelBuilder.Entity<Branch>()
            //    .Property(b => b.BranchId)
            //    .HasDefaultValueSql("NEXT VALUE FOR BranchSequence");
            base.OnModelCreating(modelBuilder);
        }
        public virtual DbSet<User> Users { get; set; }

    }
}

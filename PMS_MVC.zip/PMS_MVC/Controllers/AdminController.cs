﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using PMS_MVC.Models;
using System.Text;

namespace PMS_MVC.Controllers
{
    public class AdminController : Controller
    {
        [BindProperty]
        public UserModel User { get; set; }
        public async Task<IActionResult> Index()
        {
            try
            {
                List<UserModel> usersList = new List<UserModel>();
                using (var httpClient = new HttpClient())
                {

                    //replace the portnumber with the Ocelot Gateway portnumber
                    using (var response
                        = await httpClient.GetAsync("http://localhost:5104/api/Admin"))
                    {
                        var apiResponse = await response.Content.ReadAsStringAsync();
                        usersList = JsonConvert.DeserializeObject<List<UserModel>>(apiResponse);
                    }
                }
                return View(usersList);
            }
            catch (Exception ex)
            {

                return RedirectToAction("Error");
            }
        }
        public IActionResult AdminLogin()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AdminLogin(Admin aLog)
        {
            using (var httpclient = new HttpClient())
            {
                StringContent content = new StringContent
                    (JsonConvert.SerializeObject(aLog)
                    , Encoding.UTF8
                    , "application/json");
                using (var response = httpclient.PostAsync("http://localhost:5104/api/Admin/AdminLogin/", content))
                {
                    if (response.Result.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ViewData["Message"] = "Invalid Login";
                    }
                }
            }

            return View();
        }
        public async Task<IActionResult> ViewDetails(int id)
        {
            try
            {
                UserModel user = null;
                using (var httpClient = new HttpClient())
                {
                    //replace the portnumber with the Ocelot Gateway portnumber
                    using (var response = await httpClient.GetAsync("http://localhost:5104/api/Admin/" + id))
                    {
                        var apiResponse = await response.Content.ReadAsStringAsync();
                        user = JsonConvert.DeserializeObject<UserModel>(apiResponse);
                    }
                }
                return View(user);
            }
            catch (Exception ex)
            {
                return RedirectToAction("Error");
            }
        }
        public async Task<IActionResult> Edit(int id)
        {
            UserModel user = null;
            using (var httpclient = new HttpClient())
            {
                using (var response = await httpclient.GetAsync("http://localhost:5104/api/Admin/" + id))
                {
                    var apiresponse = await response.Content.ReadAsStringAsync();
                    user = JsonConvert.DeserializeObject<UserModel>(apiresponse);
                }
            }
            return View(user);
        }
        [HttpPost]
        public async Task<IActionResult> Edit(UserModel custObj, int id)
        {
            using (var httpclient = new HttpClient())
            {
                StringContent content = new StringContent
                    (JsonConvert.SerializeObject(custObj)
                    , Encoding.UTF8
                    , "application/json");
                using (var response = await httpclient.PutAsync("http://localhost:5104/api/Admin/" + id, content))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ViewData["Message"] = "Invalid user Update";
                    }
                }
            }

            return View(custObj);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            if (ModelState.IsValid)
            {
                using (var httpclient = new HttpClient())
                {
                    using (var response = httpclient.DeleteAsync("http://localhost:5104/api/Admin/" + id))
                    {
                        if (response.Result.IsSuccessStatusCode)
                        {
                            return RedirectToAction("Index");
                        }
                        else
                        {
                            ViewData["Message"] = "user Deletion failed!!";
                        }
                    }
                }
            }
            return View();
        }
    }
}

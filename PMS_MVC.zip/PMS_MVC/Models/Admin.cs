﻿using System.ComponentModel.DataAnnotations;

namespace PMS_MVC.Models
{
    public class Admin
    {
        [Required]
        public string UserName { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
